<?php
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/css/balloon.css").'">';
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/css/bootstrap.min.css").'">';
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/css/bootstrap-theme.min.css").'">';
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/css/font-awesome.min.css").'">';
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/css/bootstrap-select.min.css").'">';
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/css/core.css").'">';
echo '<link rel="stylesheet" type="text/css" href="'.base_url("assets/jqueryui/jquery-ui.min.css").'">';

?>