<?php
echo '<script type="text/javascript" src="'.base_url("/assets/js/jquery.min.js").'"></script>';
echo '<script type="text/javascript" src="'.base_url("/assets/js/bootstrap.min.js").'"></script>';
echo '<script type="text/javascript" src="'.base_url("/assets/js/jquery-ui.min.js").'"></script>';
echo '<script type="text/javascript" src="'.base_url("/assets/js/bootstrap-select.min.js").'"></script>';
echo '<script type="text/javascript" src="'.base_url("/assets/js/core.js").'"></script>';

?>
